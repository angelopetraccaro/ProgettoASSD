package DAO;

import javax.ws.rs.core.Response;

import model.Stato;

public interface StatoDAO {
	public Response getStato(int id);
	public void updateStato(Stato state);
	public void createStato(Stato state);
}
