package REST;

import javax.ws.rs.core.Response;

import DAO.StatoDAO;
import DAO.StatoDAOImpl;


public class RestInterfaceImplementation implements Rest_interface {
	@Override
	public Response getStatus(String id) {
	 try {
		 System.out.println("vengo chiamato REST");
		 // legge dal db
		 StatoDAO daoImpl = new StatoDAOImpl();
		 Response resp = daoImpl.getStato(Integer.parseInt(id));
     return resp;
	
	 }catch (Exception e) {
		// TODO: handle exception
	 }
	return null;  
	}
}
