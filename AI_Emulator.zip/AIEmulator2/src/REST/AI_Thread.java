package REST;

import DAO.StatoDAOImpl;
import model.Stato;

public class AI_Thread extends Thread{

	public AI_Thread(int id,String mod) {
		super();
		this.id=id;
		this.mod=mod;
	}
	
	public void run() {
		try {
			StatoDAOImpl DAOImpl = new StatoDAOImpl();
			DAOImpl.createStato(new Stato(id,-1));
			
			sleep(2000);
			 
			if(!mod.equals("esce") && ParkingAgentREST.capienza>=0 ) {
				DAOImpl.updateStato(new Stato(id,ParkingAgentREST.capienza));  
				if(ParkingAgentREST.capienza != 0) {
					 ParkingAgentREST.capienza-=1;
				}
				else System.out.println("Tentato ingresso con capienza="+ParkingAgentREST.capienza);
			}
			else if(mod.equals("esce") && ParkingAgentREST.capienza<3) {
				 ParkingAgentREST.capienza+=1; 
				 DAOImpl.updateStato(new Stato(id,ParkingAgentREST.capienza));
		    }
		}catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	private int id;
	private String mod;
}
